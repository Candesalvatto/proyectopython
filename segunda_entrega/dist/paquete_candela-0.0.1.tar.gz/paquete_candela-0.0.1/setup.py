from setuptools import setup

setup(
    name= 'paquete_candela',
    version= '0.0.1',
    description= 'Paquete redistribuible de Candela Salvatto',
    author= 'Candela Salvatto',
    author_email= 'cande_salvatto12@hotmail.com',
    packages=['mi_paquete_local']
)